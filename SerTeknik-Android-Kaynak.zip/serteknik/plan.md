# Ser Teknik Elektronik — İnceleme ve geliştirme planı

## Mevcut durum

WebDev tarafından oluşturulan proje Expo Router/React Native/TypeScript/NativeWind başlangıç şablonudur. Önceden çalışan Ser Teknik ekranları, gerçek API uçları, iş veritabanı, marka görselleri veya mevcut Android kaynak kodu bu çalışma alanına bağlı değildir. Başlangıçta yalnızca kullanıcı tablosu ve örnek auth router bulunuyordu.

## Uygulanan ilk geliştirme

- Türkçe kırmızı-beyaz marka kabuğu ve mobil öncelikli ana sayfa.
- Uydu sistemleri ana hizmet olacak şekilde hizmet kataloğu.
- Servis talebi formu: hizmet türü, ad soyad, telefon, ilçe, adres, açıklama ve fotoğraf ekleme alanı.
- Talep takip ekranı ve durum zaman çizgisi.
- Hesap giriş/kayıt görünümü.
- Avcılar, Esenyurt, Beylikdüzü, Büyükçekmece ve 0501 954 41 15 bilgileri.
- Bildirim, WhatsApp, fotoğraf depolama ve backend bağlantısı hazır değilken sahte başarı üretmeyen bilgilendirme davranışı.
- Gereksiz mikrofon, ses ve arka plan medya izinleri kaldırıldı; yalnızca bildirim izni bırakıldı.

## Blokajlar / sonraki zorunlu iş

Mevcut uygulama kaynak kodu ve backend erişimi paylaşılmadığı için mevcut özellikleri koruma ve gerçek sisteme bağlama incelemesi yapılamıyor. Gerçek müşteri, servis, stok, finans, KDV, rol/yetki, audit, bildirim, fotoğraf yükleme ve WhatsApp doğrulama akışları için mevcut API/DB bilgisi veya erişim yetkisi gerekir. Bu bağlantılar kurulmadan uygulama tamamlandı veya APK üretime hazır olarak gösterilmeyecektir.

## Tasarım yönü

Sade teknik servis güveni: kırmızı marka aksanı, beyaz kartlar, yüksek kontrast, tek elle erişilebilir düğmeler, kısa metinler ve durum renkleri. Marka görselleri sağlandığında yer tutucu ikonların yerine mevcut logo ve fotoğraflar kullanılacaktır.
