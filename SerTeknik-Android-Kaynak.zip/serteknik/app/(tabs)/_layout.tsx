import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Platform } from "react-native";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 56 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.tint,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          paddingTop: 8,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: colors.background,
          borderTopColor: colors.border,
          borderTopWidth: 0.5,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Ana Sayfa",
          tabBarIcon: ({ color }) => <IconSymbol size={28} name="house.fill" color={color} />,
        }}
      />
      <Tabs.Screen name="service" options={{ title: "Servis", tabBarIcon: ({ color }) => <MaterialCommunityIcons size={27} name="wrench-outline" color={color} /> }} />
      <Tabs.Screen name="tracking" options={{ title: "Takip", tabBarIcon: ({ color }) => <MaterialCommunityIcons size={27} name="magnify" color={color} /> }} />
      <Tabs.Screen name="account" options={{ title: "Hesabım", tabBarIcon: ({ color }) => <MaterialCommunityIcons size={27} name="account-outline" color={color} /> }} />
    </Tabs>
  );
}
