import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";

import { ScreenContainer } from "@/components/screen-container";

const RED = "#C91F2B";
const INK = "#191B20";
const MUTED = "#6D727C";
const SOFT = "#FFF4F4";

const services = [
  { title: "Uydu Sistemleri", subtitle: "Kurulum, ayar ve sinyal sorunları", icon: "satellite-variant" as const },
  { title: "İnternet", subtitle: "Modem, kablosuz ağ ve bağlantı", icon: "wifi" as const },
  { title: "Güvenlik Kamerası", subtitle: "Kurulum, bakım ve uzaktan izleme", icon: "cctv" as const },
];

export default function HomeScreen() {
  const [notice, setNotice] = useState(false);

  return (
    <ScreenContainer containerClassName="bg-[#FAFAFB]" edges={["top", "left", "right"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.topbar}>
          <View style={styles.brandMark}><MaterialCommunityIcons name="satellite-uplink" size={24} color="#FFF" /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>SER TEKNİK</Text>
            <Text style={styles.brand}>Elektronik</Text>
          </View>
          <Pressable style={styles.iconButton} onPress={() => setNotice(!notice)} accessibilityLabel="Bildirimler">
            <Feather name="bell" size={20} color={INK} />
            <View style={styles.dot} />
          </Pressable>
        </View>

        {notice && <View style={styles.notice}><Feather name="info" size={18} color={RED} /><Text style={styles.noticeText}>Bildirimler API bağlantısı hazır olduğunda burada görünecek.</Text></View>}

        <View style={styles.hero}>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroKicker}>BİZ HAZIRIZ</Text>
            <Text style={styles.heroTitle}>Sinyaliniz hiç{`\n`}kesilmesin.</Text>
            <Text style={styles.heroBody}>Uydu, internet ve kamera ihtiyaçlarınız için uzman servis.</Text>
            <Pressable style={styles.primaryButton} onPress={() => setNotice(true)}><Text style={styles.primaryText}>Servis talebi oluştur</Text><Feather name="arrow-up-right" size={18} color="#FFF" /></Pressable>
          </View>
          <View style={styles.heroOrb}><MaterialCommunityIcons name="satellite-variant" size={58} color={RED} /></View>
        </View>

        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>Hizmetlerimiz</Text><Text style={styles.sectionHint}>Size uygun olanı seçin</Text></View>
        {services.map((service) => <Pressable key={service.title} style={styles.serviceCard} onPress={() => setNotice(true)}>
          <View style={styles.serviceIcon}><MaterialCommunityIcons name={service.icon} size={25} color={RED} /></View>
          <View style={{ flex: 1 }}><Text style={styles.serviceTitle}>{service.title}</Text><Text style={styles.serviceSubtitle}>{service.subtitle}</Text></View>
          <Feather name="chevron-right" size={20} color="#A0A4AB" />
        </Pressable>)}

        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>Hızlı işlemler</Text></View>
        <View style={styles.quickRow}>
          <Pressable style={styles.quickCard} onPress={() => setNotice(true)}><Feather name="search" size={21} color={RED} /><Text style={styles.quickTitle}>Talep takip</Text><Text style={styles.quickBody}>Durumunu görüntüle</Text></Pressable>
          <Pressable style={styles.quickCard} onPress={() => setNotice(true)}><Feather name="phone-call" size={21} color={RED} /><Text style={styles.quickTitle}>Bizi ara</Text><Text style={styles.quickBody}>0501 954 41 15</Text></Pressable>
        </View>
        <View style={styles.area}><Feather name="map-pin" size={17} color={RED} /><Text style={styles.areaText}>Hizmet bölgeleri: Avcılar · Esenyurt · Beylikdüzü · Büyükçekmece</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 34, gap: 14 },
  topbar: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 8 },
  brandMark: { width: 44, height: 44, borderRadius: 14, backgroundColor: RED, alignItems: "center", justifyContent: "center" },
  eyebrow: { fontSize: 10, letterSpacing: 2, color: RED, fontWeight: "800" },
  brand: { fontSize: 19, color: INK, fontWeight: "800", marginTop: -1 },
  iconButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#FFF", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#EEE" },
  dot: { position: "absolute", right: 10, top: 9, width: 7, height: 7, borderRadius: 4, backgroundColor: RED },
  notice: { flexDirection: "row", gap: 9, padding: 12, borderRadius: 12, backgroundColor: SOFT, alignItems: "center" },
  noticeText: { flex: 1, color: MUTED, fontSize: 12, lineHeight: 17 },
  hero: { backgroundColor: RED, borderRadius: 23, padding: 22, minHeight: 202, flexDirection: "row", overflow: "hidden" },
  heroKicker: { color: "#FFC5C9", fontSize: 10, fontWeight: "800", letterSpacing: 1.5 },
  heroTitle: { color: "#FFF", fontSize: 29, lineHeight: 32, fontWeight: "900", marginTop: 6 },
  heroBody: { color: "#FFE7E8", fontSize: 12, lineHeight: 18, marginTop: 10, maxWidth: 190 },
  primaryButton: { backgroundColor: "#FFF", borderRadius: 12, paddingHorizontal: 13, paddingVertical: 11, flexDirection: "row", alignItems: "center", gap: 7, alignSelf: "flex-start", marginTop: 16 },
  primaryText: { color: RED, fontSize: 12, fontWeight: "800" },
  heroOrb: { position: "absolute", right: -24, bottom: -28, width: 135, height: 135, borderRadius: 70, backgroundColor: "#E84B55", alignItems: "center", justifyContent: "center", opacity: 0.95 },
  sectionHeader: { marginTop: 11, flexDirection: "row", justifyContent: "space-between", alignItems: "baseline" },
  sectionTitle: { color: INK, fontSize: 18, fontWeight: "800" },
  sectionHint: { color: MUTED, fontSize: 11 },
  serviceCard: { minHeight: 76, backgroundColor: "#FFF", borderRadius: 17, padding: 13, flexDirection: "row", alignItems: "center", gap: 12, borderWidth: 1, borderColor: "#F0F0F2" },
  serviceIcon: { width: 48, height: 48, borderRadius: 14, backgroundColor: SOFT, alignItems: "center", justifyContent: "center" },
  serviceTitle: { color: INK, fontWeight: "800", fontSize: 14 },
  serviceSubtitle: { color: MUTED, fontSize: 11, marginTop: 4 },
  quickRow: { flexDirection: "row", gap: 11 },
  quickCard: { flex: 1, backgroundColor: "#FFF", borderRadius: 16, padding: 15, borderWidth: 1, borderColor: "#F0F0F2", gap: 6 },
  quickTitle: { color: INK, fontWeight: "800", fontSize: 13, marginTop: 4 },
  quickBody: { color: MUTED, fontSize: 10 },
  area: { marginTop: 5, padding: 13, borderRadius: 14, backgroundColor: "#FFF8F8", flexDirection: "row", gap: 8, alignItems: "center" },
  areaText: { flex: 1, color: MUTED, fontSize: 10, lineHeight: 15 },
});
