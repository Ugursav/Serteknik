# Ser Teknik Elektronik — TODO

- [x] Türkçe mobil müşteri kabuğu, kırmızı-beyaz görsel dil ve hizmet bölgeleri.
- [x] Hizmet kataloğu: uydu, internet, güvenlik kamerası.
- [x] Servis talep formu ve talep takip ekranı için kullanıcı akışı.
- [x] Hesap giriş/kayıt görünümü.
- [x] Gereksiz mikrofon/ses/arka plan izinlerini kaldırma.
- [ ] Mevcut Android kaynak kodunu ve gerçek API/backend'i inceleyip çalışan özellikleri koruma.
- [ ] Gerçek veritabanı tabloları: customers, service_requests, statuses, products, stock_movements, income, expenses, audit_logs.
- [ ] Sunucu tarafı müşteri sahipliği, yönetici/çalışan rolü ve izin middleware'i.
- [ ] Gerçek şifre yenileme, iptal edilebilir oturum ve güvenli kimlik doğrulama.
- [ ] Benzersiz takip numarası üretimi ve kalıcı servis kaydı.
- [ ] Fotoğraf yükleme/storage ve uygulama bildirimi.
- [ ] WhatsApp gönderim sonucunu doğrulayan akış.
- [ ] Stok düşümü, düşük stok uyarısı ve audit geçmişi.
- [ ] KDV dahil/hariç, gelir-gider, tahsilat, bakiye, kâr ve rapor hesapları.
- [ ] Gerçek kayıtlarla tutarlı dışa aktarma.
- [ ] Entegrasyon verileri sağlandıktan sonra otomatik ve gerçek koşul testleri.
- [ ] Kabul edilmiş checkpoint sonrasında Dashboard üzerinden Android APK/AAB üretimi.
