# Ser Teknik Elektronik — Android APK hazırlığı

- Marka tasarımı ve `assets/images/` içindeki görseller değiştirilmemiştir.
- `eas.json` içine Android için doğrudan kurulabilir APK üreten `preview` profili eklenmiştir.
- Üretim mağaza paketi için `production` profili AAB üretir.

## APK üretimi

Bu proje Expo/EAS kullanır. APK üretmek için Expo hesabına giriş ve projeyi EAS projesine bağlama gerekir:

1. `npm install` veya `pnpm install`
2. `npx eas login`
3. `npx eas build:configure` (sorulursa mevcut Expo projesiyle ilişkilendir)
4. `npx eas build --platform android --profile preview`

Build tamamlandığında EAS bir APK indirme bağlantısı verir.

## Önemli mevcut sınırlama

Bu kaynakta bazı ekranlar görsel/örnek akış seviyesindedir. Gerçek servis kaydı, kimlik doğrulama, fotoğraf depolama, bildirim ve takip için backend/API doğrulaması gerekir. Bunlar doğrulanmadan kullanıcıya gerçek servis talebi gönderildiği veya takip numarasının veritabanına kaydedildiği söylenmemelidir.
